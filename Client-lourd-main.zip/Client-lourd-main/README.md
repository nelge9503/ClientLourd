# Client-lourd
Ce projet consiste à gérer les participants à des salons sur des thématiques autour des vins, des produits alimen-
taires des régions et des accessoires de table.
Pour entrer sur un salon, un visiteur doit être muni d’un badge comportant ses
Nom, Prenom, Ville de résidence ainsi qu’un codeBarre unique associé.

Ce projet a été réalisé en C#, il permet de rechercher, ajouter, modifier et supprimer un participant et de pouvoir générer un QR Code qui pourra être imprimer sur le badge des participants.

Vous trouverez ci-dessus un fichier zip contenant le projet en question et ainsi que plusieurs vidéo qui montre le mode de fonctionnement du projet.

